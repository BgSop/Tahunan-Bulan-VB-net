﻿Imports MySql.Data.MySqlClient
Public Class login

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim user, pass, hak As String
        user = vuser.Text
        pass = vpass.Text
        hak = vlevel.SelectedItem
        str = "select * from tbl_login where username='" + user + "' and password='" + pass + "' and level='" + hak + "'"
        cmd = New MySqlCommand(str, conn)
        dr = cmd.ExecuteReader
        If dr.HasRows = True Then
            If hak = "Admin" Then
                menu_utama.BarangToolStripMenuItem.Enabled = True
                menu_utama.userToolStripMenuItem.Enabled = True
                menu_utama.SupplierToolStripMenuItem.Enabled = True
                menu_utama.customerToolStripMenuItem.Enabled = True
                menu_utama.PembelianToolStripMenuItem.Enabled = True
                menu_utama.PenjualanToolStripMenuItem.Enabled = True
                menu_utama.AnalisaEOQToolStripMenuItem.Enabled = True
                menu_utama.DataPenjualanToolStripMenuItem.Enabled = True
                menu_utama.DataPembelianToolStripMenuItem.Enabled = True
                menu_utama.PersediaanToolStripMenuItem.Enabled = True
                menu_utama.CetakFakturToolStripMenuItem.Enabled = True
                menu_utama.DataEOQ.Enabled = True
                menu_utama.Show()
                Me.Hide()
            ElseIf hak = "Pimpinan" Then
                menu_utama.BarangToolStripMenuItem.Enabled = False
                menu_utama.userToolStripMenuItem.Enabled = True
                menu_utama.SupplierToolStripMenuItem.Enabled = False
                menu_utama.customerToolStripMenuItem.Enabled = False
                menu_utama.PembelianToolStripMenuItem.Enabled = False
                menu_utama.PenjualanToolStripMenuItem.Enabled = False
                menu_utama.AnalisaEOQToolStripMenuItem.Enabled = False
                menu_utama.DataPenjualanToolStripMenuItem.Enabled = True
                menu_utama.DataPembelianToolStripMenuItem.Enabled = True
                menu_utama.PersediaanToolStripMenuItem.Enabled = True
                menu_utama.DataEOQ.Enabled = True
                menu_utama.CetakFakturToolStripMenuItem.Enabled = True
                menu_utama.Show()
                Me.Hide()
            ElseIf hak = "Bag.gudang" Then
                menu_utama.BarangToolStripMenuItem.Enabled = True
                menu_utama.userToolStripMenuItem.Enabled = False
                menu_utama.SupplierToolStripMenuItem.Enabled = True
                menu_utama.customerToolStripMenuItem.Enabled = False
                menu_utama.PembelianToolStripMenuItem.Enabled = True
                menu_utama.PenjualanToolStripMenuItem.Enabled = False
                menu_utama.AnalisaEOQToolStripMenuItem.Enabled = True
                menu_utama.DataPenjualanToolStripMenuItem.Enabled = False
                menu_utama.DataPembelianToolStripMenuItem.Enabled = False
                menu_utama.PersediaanToolStripMenuItem.Enabled = False
                menu_utama.DataEOQ.Enabled = False
                menu_utama.CetakFakturToolStripMenuItem.Enabled = False
                menu_utama.Show()
                Me.Hide()
            End If
        Else
            MessageBox.Show("Username atau Password yang dimasukkan salah", "Konfirmasi", MessageBoxButtons.OK, MessageBoxIcon.Error)
            vuser.Focus()
        End If
        dr.Close()
        cmd.Dispose()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksi_ok()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()

    End Sub
End Class
