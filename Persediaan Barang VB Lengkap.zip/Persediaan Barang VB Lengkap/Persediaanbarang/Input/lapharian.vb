﻿Public Class lapharian

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Formlappenjualanharian.CrystalReportViewer1.SelectionFormula = "totext({tbl_penjualan1.tgljual})='" & Format(DateTimePicker1.Value, "dd/MM/yyyy") & "'"
        Formlappenjualanharian.CrystalReportViewer1.RefreshReport()
        Formlappenjualanharian.WindowState = FormWindowState.Maximized
        Formlappenjualanharian.Show()

    End Sub

    Private Sub lapharian_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()

    End Sub
End Class