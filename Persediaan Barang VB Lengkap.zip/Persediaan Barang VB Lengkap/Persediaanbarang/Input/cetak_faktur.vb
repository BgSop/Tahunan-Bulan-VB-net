﻿Imports MySql.Data.MySqlClient
Imports System.IO
Imports System.Net
Public Class cetak_faktur
    Sub Panggil()
        Call koneksi_ok()
        cmd = New MySqlCommand("select distinct (nojual) as nojual from tbl_penjualan ", conn)
        dr = cmd.ExecuteReader
        Do While dr.Read
            If dr.HasRows Then
                vnojual.Items.Add(dr.Item(0))
            End If
        Loop


    End Sub


    Private Sub vnojual_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles vnojual.SelectedIndexChanged
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_penjualan where nojual ='" & vnojual.Text & "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then

        Else
            MsgBox("Data Tidak Ada")
            vnojual.Focus()
            Exit Sub

        End If

    End Sub

    Private Sub cetak_faktur_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Panggil()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If vnojual.Text = "" Then
            Exit Sub
        Else
            Formpenjualan.CrystalReportViewer1.SelectionFormula = "{tbl_penjualan1.nojual}='" & vnojual.Text.ToString & "'"
            Formpenjualan.Refresh()
            Formpenjualan.Show()

        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()

    End Sub
End Class