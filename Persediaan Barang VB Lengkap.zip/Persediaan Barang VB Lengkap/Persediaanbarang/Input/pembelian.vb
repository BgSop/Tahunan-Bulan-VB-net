﻿Imports MySql.Data.MySqlClient
Imports System.Data.OleDb
Public Class pembelian
    Dim db As New Db()
    Private Sub bersih()
        vnopembelian.Text = ""
        vtglpembelian.Text = ""
        vkodesupplier.Text = ""
        vnamasupplier.Text = ""
        vkodebrg.Text = ""
        vnmabrg.Text = ""
        vhrgabeli.Text = ""
        vstok.Text = ""
        vjmlhbeli.Text = ""
        vhargajual.Text = ""
        vstokakhir.Text = ""
        vtotharga.Text = ""
        vkodebrg.Text = "---Pilih Kode Barang---"
        vkodesupplier.Text = "---Pilih Kode Supplier---"
    End Sub
    Private Sub tampilan()
        Call koneksi_ok()
        adr = New MySqlDataAdapter("Select * from tbl_pembelian", conn)
        adt = New DataSet
        adr.Fill(adt, "tbl_pembelian")
        DataGridView1.DataSource = adt.Tables("tbl_pembelian")
    End Sub
    Sub panggil()
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_supplier", conn)
        dr = cmd.ExecuteReader
        Do While dr.Read
            If dr.HasRows Then
                vkodesupplier.Items.Add(dr.Item(0))
            End If
        Loop
    End Sub
    Sub panggilbarang()
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_barang", conn)
        dr = cmd.ExecuteReader
        Do While dr.Read
            If dr.HasRows Then
                vkodebrg.Items.Add(dr.Item(0))
            End If
        Loop
    End Sub
    Sub otomatis()
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_pembelian order by nopembelian desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If Not dr.HasRows Then
            vnopembelian.Text = "NB" + "0001"
        Else
            vnopembelian.Text = Val(Microsoft.VisualBasic.Mid(dr.Item("nopembelian").ToString, 4, 3)) + 1
            If Len(vnopembelian.Text) = 1 Then
                vnopembelian.Text = "NB000" & vnopembelian.Text & ""
            ElseIf Len(vnopembelian.Text) = 2 Then
                vnopembelian.Text = "NB00" & vnopembelian.Text & ""
            ElseIf Len(vnopembelian.Text) = 3 Then
                vnopembelian.Text = "NB0" & vnopembelian.Text & ""
            End If
        End If
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub valamat_supplier_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Pembelian_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call otomatis()
        Call koneksi_ok()
        vnopembelian.Enabled = False
        Call panggil()
        Call panggilbarang()
        Call tampilan()
    End Sub
    Private Sub vkodebrg_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles vkodebrg.SelectedIndexChanged
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_barang where kodebrg ='" & vkodebrg.Text & "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            vnmabrg.Text = dr.Item("namabrg")
            vhrgabeli.Text = dr.Item("hargabeli")
            vhargajual.Text = dr.Item("hargajual")
            vstok.Text = dr.Item("jumlah")

        Else
            MsgBox("Data Tidak Ada")
            vkodebrg.Focus()
            Exit Sub
        End If


    End Sub

    Private Sub vkodesupplier_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles vkodesupplier.SelectedIndexChanged
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_supplier where Id_supplier ='" & vkodesupplier.Text & "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            vnamasupplier.Text = dr.Item("Nama_supplier")
        Else
            MsgBox("Data Tidak Ada")
            vkodesupplier.Focus()
            Exit Sub
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If vnopembelian.Text = "" Or vnopembelian.Text = "" Or vkodesupplier.Text = "" Or vkodebrg.Text = "" Then
            MsgBox("Masih ada data yang belum dilengkapi")
            Exit Sub
        Else

            Call koneksi_ok()
            cmd = New MySqlCommand("select * from tbl_pembelian where nopembelian='" & vnopembelian.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If Not dr.HasRows Then
                Call koneksi_ok()
                Dim simpan As String = "insert into tbl_pembelian values('" & vnopembelian.Text & "','" & Format(vtglpembelian.Value, "yyyy-MM-dd") & "','" & vkodesupplier.Text & "','" & vkodebrg.Text & "','" & vjmlhbeli.Text & "','" & vstokakhir.Text & "','" & vtotharga.Text & "')"
                cmd = New MySqlCommand(simpan, conn)
                cmd.ExecuteNonQuery()
            Else
                Call koneksi_ok()
                Dim edit As String = "update tbl_pembelian set nopembelian ='" & vnopembelian.Text & "',tglpembelian='" & Format(vtglpembelian.Value, "yyyy-MM-dd") & "',kodesupplier='" & vkodesupplier.Text & "', kodebrg='" & vkodebrg.Text & "' ,jumlahpesan='" & vjmlhbeli.Text & "',stokbaru='" & vstokakhir.Text & "',total='" & vtotharga.Text & "'where nopembelian='" & vnopembelian.Text & "'"
                cmd = New MySqlCommand(edit, conn)
                cmd.ExecuteNonQuery()
            End If
            Call bersih()
            Call otomatis()
            Call tampilan()

        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        vtotharga.Text = vjmlhbeli.Text * vhrgabeli.Text
        vstokakhir.Text = Val(vjmlhbeli.Text) + Val(vstok.Text)
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        On Error Resume Next
        vnopembelian.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
        vtglpembelian.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
        vkodesupplier.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
        vkodebrg.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value
        vjmlhbeli.Text = DataGridView1.Rows(e.RowIndex).Cells(4).Value
        vstokakhir.Text = DataGridView1.Rows(e.RowIndex).Cells(5).Value
        vtotharga.Text = DataGridView1.Rows(e.RowIndex).Cells(6).Value
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If vnopembelian.Text = "" Then
            vnopembelian.Focus()
            MsgBox("Kode  Harus diisi Dulu !")
            Exit Sub
        Else
            If MessageBox.Show("Hapus Data Ini ?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call koneksi_ok()
                Dim hapus As String = "delete from tbl_pembelian where nopembelian='" & vnopembelian.Text & "'"
                cmd = New MySqlCommand(hapus, conn)
                cmd.ExecuteNonQuery()
                Call bersih()
                Call tampilan()
                Call otomatis()
            Else
                Call bersih()
            End If
        End If
    End Sub

    Private Sub vtglpembelian_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles vtglpembelian.ValueChanged

    End Sub
End Class