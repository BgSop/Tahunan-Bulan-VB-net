﻿Imports MySql.Data.MySqlClient
Public Class user
    Sub otomatis()
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_login order by kodeuser desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If Not dr.HasRows Then
            vkodekaryawan.Text = "KY" + "0001"
        Else
            vkodekaryawan.Text = Val(Microsoft.VisualBasic.Mid(dr.Item("kodeuser").ToString, 4, 3)) + 1
            If Len(vkodekaryawan.Text) = 1 Then
                vkodekaryawan.Text = "KY000" & vkodekaryawan.Text & ""
            ElseIf Len(vkodekaryawan.Text) = 2 Then
                vkodekaryawan.Text = "KY00" & vkodekaryawan.Text & ""
            ElseIf Len(vkodekaryawan.Text) = 3 Then
                vkodekaryawan.Text = "KY0" & vkodekaryawan.Text & ""
            End If
        End If
    End Sub
    Sub tabel()
        Dim i As Integer
        i = Me.DataGridView1.CurrentRow.Index
        With DataGridView1.Rows.Item(i)
            vkodekaryawan.Text = .Cells(0).Value
            vnamakaryawan.Text = .Cells(1).Value
            vusername.Text = .Cells(2).Value
            vpassword.Text = .Cells(3).Value
            vlevel.Text = .Cells(4).Value
            valamatkaryawan.Text = .Cells(5).Value
            vnotlpkaryawan.Text = .Cells(6).Value

        End With
    End Sub
    Private Sub bersih()
        vkodekaryawan.Text = ""
        vnamakaryawan.Text = ""
        vusername.Text = ""
        vpassword.Text = ""
        vlevel.Text = ""
        valamatkaryawan.Text = ""
        vnotlpkaryawan.Text = ""
        vkodekaryawan.Focus()
    End Sub
    Private Sub tampilan()
        Call koneksi_ok()
        adr = New MySqlDataAdapter("select * from tbl_login", conn)
        adt = New DataSet
        adr.Fill(adt, "tbl_login")
        DataGridView1.DataSource = adt.Tables("tbl_login")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If vkodekaryawan.Text = "" Or vkodekaryawan.Text = "" Then
            MsgBox("Masih ada data yang belum dilengkapi")
            Exit Sub
        Else

            Call koneksi_ok()
            cmd = New MySqlCommand("select * from tbl_login where kodeuser='" & vkodekaryawan.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If Not dr.HasRows Then
                Call koneksi_ok()
                Dim simpan As String = "insert into tbl_login values('" & vkodekaryawan.Text & "','" & vnamakaryawan.Text & "','" & vusername.Text & "','" & vpassword.Text & "','" & vlevel.Text & "','" & valamatkaryawan.Text & "','" & vnotlpkaryawan.Text & "')"
                cmd = New MySqlCommand(simpan, conn)
                cmd.ExecuteNonQuery()
            Else
                Call koneksi_ok()
                Dim edit As String = "update tbl_login set namalengkap ='" & vnamakaryawan.Text & "',username='" & vusername.Text & "',password='" & vpassword.Text & "',level='" & vlevel.Text & "' ,alamatuser='" & valamatkaryawan.Text & "',nohpuser='" & vnotlpkaryawan.Text & "' where kodeuser='" & vkodekaryawan.Text & "'"
                cmd = New MySqlCommand(edit, conn)
                cmd.ExecuteNonQuery()
            End If
            Call bersih()
            Call tampilan()
            Call otomatis()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If vkodekaryawan.Text = "" Then
            vkodekaryawan.Focus()
            MsgBox("Kode  Harus diisi Dulu !")
            Exit Sub
        Else
            If MessageBox.Show("Hapus Data Ini ?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call koneksi_ok()
                Dim hapus As String = "delete from tbl_login where kodeuser='" & vkodekaryawan.Text & "'"
                cmd = New MySqlCommand(hapus, conn)
                cmd.ExecuteNonQuery()
                Call bersih()
                Call tampilan()
                Call otomatis()
            Else
                Call bersih()
            End If
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        tabel()
    End Sub

    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        On Error Resume Next
        vkodekaryawan.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
        vnamakaryawan.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
        vusername.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
        vpassword.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value
        vlevel.Text = DataGridView1.Rows(e.RowIndex).Cells(4).Value
        valamatkaryawan.Text = DataGridView1.Rows(e.RowIndex).Cells(5).Value
        vnotlpkaryawan.Text = DataGridView1.Rows(e.RowIndex).Cells(6).Value
    End Sub

    Private Sub karyawan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call koneksi_ok()
        vkodekaryawan.Enabled = False
        Call otomatis()
        Call tampilan()

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        bersih()
    End Sub

    Private Sub vkodekaryawan_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles vkodekaryawan.TextChanged

    End Sub
End Class