﻿Public Class laptahunan

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            If ComboBox2.Text = "" Then
                MessageBox.Show("data tidak lengap")
            Else
                Formlappenjualantahunan.CrystalReportViewer1.SelectionFormula = "{Command.tahun}=" & Val(ComboBox2.Text)
                Formlappenjualantahunan.CrystalReportViewer1.RefreshReport()
                Formlappenjualantahunan.WindowState = FormWindowState.Maximized
                Formlappenjualantahunan.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub tampiltahunan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class