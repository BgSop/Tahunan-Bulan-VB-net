﻿Imports MySql.Data.MySqlClient
Imports System.Data.OleDb
Public Class penjualan1
    Dim db As New Db()
    Private Sub bersih()
        vnofak.Text = ""
        vtgl.Text = ""
        vkodebrg.Text = ""
        vkodekonsumen.Text = ""
        vnmabrg.Text = ""
        vnamakonsumen.Text = ""
        vhrgajual.Text = ""
        vstok.Text = ""
        vjmlhbeli.Text = ""
        vdiskon.Text = ""
        vtotharga.Text = ""
        vstoksisa.Text = ""
        vtotbayar.Text = ""
        vkembalian.Text = ""
        vkodebrg.Text = "---Pilih Kode Barang---"
        vkodekonsumen.Text = "---Pilih Kode Konsumen---"
    End Sub
    Private Sub tampilan()
        Call koneksi_ok()
        adr = New MySqlDataAdapter("Select * from tbl_penjualan", conn)
        adt = New DataSet
        adr.Fill(adt, "tbl_penjualan")
        DataGridView1.DataSource = adt.Tables("tbl_penjualan")
    End Sub
    Sub panggil()
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_customer", conn)
        dr = cmd.ExecuteReader
        Do While dr.Read
            If dr.HasRows Then
                vkodekonsumen.Items.Add(dr.Item(0))
            End If
        Loop
    End Sub
    Sub panggilbarang()
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_barang", conn)
        dr = cmd.ExecuteReader
        Do While dr.Read
            If dr.HasRows Then
                vkodebrg.Items.Add(dr.Item(0))
            End If
        Loop
    End Sub

    Sub otomatis()
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_penjualan order by nojual desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If Not dr.HasRows Then
            vnofak.Text = "NF" + "0001"
        Else
            vnofak.Text = Val(Microsoft.VisualBasic.Mid(dr.Item("nojual").ToString, 4, 3)) + 1
            If Len(vnofak.Text) = 1 Then
                vnofak.Text = "NF000" & vnofak.Text & ""
            ElseIf Len(vnofak.Text) = 2 Then
                vnofak.Text = "NF00" & vnofak.Text & ""
            ElseIf Len(vnofak.Text) = 3 Then
                vnofak.Text = "NF0" & vnofak.Text & ""
            End If
        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)

    End Sub

    Private Sub penjualan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call otomatis()
        Call koneksi_ok()
        vnofak.Enabled = False
        Call panggil()
        Call panggilbarang()
        Call tampilan()


    End Sub

    Private Sub vkodekonsumen_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles vkodekonsumen.SelectedIndexChanged
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_customer where Id_konsumen ='" & vkodekonsumen.Text & "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            vnamakonsumen.Text = dr.Item("Nama_konsumen")
        Else
            MsgBox("Data Tidak Ada")
            vkodekonsumen.Focus()
            Exit Sub
        End If

    End Sub
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Me.Close()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If vnofak.Text = "" Or vnofak.Text = "" Or vkodekonsumen.Text = "" Or vkodebrg.Text = "" Then
            MsgBox("Masih ada data yang belum dilengkapi")
            Exit Sub
        Else

            Call koneksi_ok()
            cmd = New MySqlCommand("select * from tbl_penjualan where nojual='" & vnofak.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If Not dr.HasRows Then
                Call koneksi_ok()
                Dim simpan As String = "insert into tbl_penjualan values('" & vnofak.Text & "','" & Format(vtgl.Value, "yyyy-MM-dd") & "','" & vkodekonsumen.Text & "','" & vkodebrg.Text & "','" & vjmlhbeli.Text & "','" & vdiskon.Text & "','" & vtotharga.Text & "','" & vtotbayar.Text & "','" & vkembalian.Text & "')"
                cmd = New MySqlCommand(simpan, conn)
                cmd.ExecuteNonQuery()
                MsgBox("Data Sukses Disimpan")
            Else
                Call koneksi_ok()
                Dim edit As String = "update tbl_penjualan set nojual ='" & vnofak.Text & "',tgljual='" & Format(vtgl.Value, "yyyy-MM-dd") & "',Id_konsumen='" & vkodekonsumen.Text & "', kodebrg='" & vkodebrg.Text & "' ,jumlahpesan='" & vjmlhbeli.Text & "' ,diskon='" & vdiskon.Text & "' ,total='" & vtotbayar.Text & "' ,kembalian='" & vkembalian.Text & "' where nojual='" & vnofak.Text & "'"
                cmd = New MySqlCommand(edit, conn)
                cmd.ExecuteNonQuery()
                MsgBox("Data Berhasil Diubah", MsgBoxStyle.Information, "Information")
            End If
            Call bersih()
            Call otomatis()
            Call tampilan()
        End If
    End Sub
    Private Sub vkodebrg_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles vkodebrg.SelectedIndexChanged
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_barang where kodebrg ='" & vkodebrg.Text & "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            vnmabrg.Text = dr.Item("namabrg")
            vhrgajual.Text = dr.Item("hargajual")
            vstok.Text = dr.Item("jumlah")

        Else
            MsgBox("Data Tidak Ada")
            vkodebrg.Focus()
            Exit Sub
        End If

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        vtotharga.Text = vhrgajual.Text - (vhrgajual.Text * (vdiskon.Text / 100))
        vstoksisa.Text = Val(vstok.Text) - Val(vjmlhbeli.Text)

    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        vkembalian.Text = vtotbayar.Text - vtotharga.Text
    End Sub

    Private Sub DataGridView1_CellContentClick_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        On Error Resume Next
        vnofak.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
        vtgl.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
        vkodekonsumen.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
        vkodebrg.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value
        vjmlhbeli.Text = DataGridView1.Rows(e.RowIndex).Cells(4).Value
        vdiskon.Text = DataGridView1.Rows(e.RowIndex).Cells(5).Value
        vtotharga.Text = DataGridView1.Rows(e.RowIndex).Cells(6).Value
        vtotbayar.Text = DataGridView1.Rows(e.RowIndex).Cells(7).Value
        vkembalian.Text = DataGridView1.Rows(e.RowIndex).Cells(8).Value
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If vnofak.Text = "" Then
            vnofak.Focus()
            MsgBox("Kode  Harus diisi Dulu !")
            Exit Sub
        Else
            If MessageBox.Show("Hapus Data Ini ?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call koneksi_ok()
                Dim hapus As String = "delete from tbl_penjualan where nojual='" & vnofak.Text & "'"
                cmd = New MySqlCommand(hapus, conn)
                cmd.ExecuteNonQuery()
                Call bersih()
                Call tampilan()
                Call otomatis()
            Else
                Call bersih()
            End If
        End If
    End Sub

    Private Sub Button3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If vnofak.Text = "" Then
            vnofak.Focus()
            MsgBox("Kode  Harus diisi Dulu !")
            Exit Sub
        Else
            If MessageBox.Show("Hapus Data Ini ?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call koneksi_ok()
                Dim hapus As String = "delete from tbl_penjualan where nojual='" & vnofak.Text & "'"
                cmd = New MySqlCommand(hapus, conn)
                cmd.ExecuteNonQuery()
                Call bersih()
                Call tampilan()
                Call otomatis()
            Else
                Call bersih()
            End If
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Formpenjualan.CrystalReportViewer1.SelectionFormula = "totext({tbl_penjualan1.tgljual}) = '" & Format(vtgl.Value, "dd/MM/yyyy") & "'"
        Formpenjualan.CrystalReportViewer1.RefreshReport()
        Formpenjualan.WindowState = FormWindowState.Maximized
        Formpenjualan.Show()
    End Sub
End Class

