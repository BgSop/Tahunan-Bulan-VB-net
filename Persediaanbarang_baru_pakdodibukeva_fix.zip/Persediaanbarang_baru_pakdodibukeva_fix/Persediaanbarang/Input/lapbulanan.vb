﻿Imports MySql.Data.MySqlClient
Public Class lapbulanan
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cetak.Click
        Dim int_bulan As Integer
        Try
            Select Case ComboBox1.Text
                Case "Januari"
                    int_bulan = 1
                Case "Februari"
                    int_bulan = 2
                Case "Maret"
                    int_bulan = 3
                Case "April"
                    int_bulan = 4
                Case "Mei"
                    int_bulan = 5
                Case "Juni"
                    int_bulan = 6
                Case "Juli"
                    int_bulan = 7
                Case "Agustus"
                    int_bulan = 8
                Case "September"
                    int_bulan = 9
                Case "Oktober"
                    int_bulan = 10
                Case "November"
                    int_bulan = 11
                Case "Dsemebr"
                    int_bulan = 12
            End Select
            If ComboBox1.Text = "" Or ComboBox2.Text = "" Then
                MessageBox.Show("data tidak lengkap")
            Else
                fromlappenjualanbulanan.CrystalReportViewer1.SelectionFormula = "Month({tbl_penjualan1.tgljual})=" & Val(ComboBox1.Text) & "and Year({tbl_penjualan1.tgljual})=" & Val(ComboBox2.Text)
                fromlappenjualanbulanan.CrystalReportViewer1.RefreshReport()
                fromlappenjualanbulanan.WindowState = FormWindowState.Maximized
                fromlappenjualanbulanan.Show()
            End If
        Catch ex As Exception
            MessageBox.Show("Report Eror", "form filter report", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub tampilbulanan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged

    End Sub
End Class