﻿Imports MySql.Data.MySqlClient
Public Class Barang
    Sub otomatis()
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_barang order by kodebrg desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If Not dr.HasRows Then
            vkodebrg.Text = "KB" + "0001"
        Else
            vkodebrg.Text = Val(Microsoft.VisualBasic.Mid(dr.Item("kodebrg").ToString, 4, 3)) + 1
            If Len(vkodebrg.Text) = 1 Then
                vkodebrg.Text = "KB000" & vkodebrg.Text & ""
            ElseIf Len(vkodebrg.Text) = 2 Then
                vkodebrg.Text = "KB00" & vkodebrg.Text & ""
            ElseIf Len(vkodebrg.Text) = 3 Then
                vkodebrg.Text = "KB0" & vkodebrg.Text & ""
            End If
        End If

    End Sub
    Sub tabel()
        Dim i As Integer
        i = Me.DataGridView1.CurrentRow.Index
        With DataGridView1.Rows.Item(i)
            vkodebrg.Text = .Cells(0).Value
            vnmbrg.Text = .Cells(1).Value
            vjenis.Text = .Cells(2).Value
            vsatuan.Text = .Cells(3).Value
            vhargabeli.Text = .Cells(4).Value
            vhrgajual.Text = .Cells(5).Value
            vjmlbrg.Text = .Cells(6).Value

        End With
    End Sub
    Private Sub bersih()
        vkodebrg.Text = ""
        vnmbrg.Text = ""
        vjenis.Text = ""
        vsatuan.Text = ""
        vhargabeli.Text = ""
        vhrgajual.Text = ""
        vjmlbrg.Text = ""
        vkodebrg.Focus()
    End Sub
    Private Sub tampilan()
        Call koneksi_ok()
        adr = New MySqlDataAdapter("select * from tbl_barang", conn)
        adt = New DataSet
        adr.Fill(adt, "tbl_barang")
        DataGridView1.DataSource = adt.Tables("tbl_barang")
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If vkodebrg.Text = "" Or vkodebrg.Text = "" Or vjenis.Text = "" Or vsatuan.Text = "" Then
            MsgBox("Masih ada data yang belum dilengkapi")
            Exit Sub
        Else

            Call koneksi_ok()
            cmd = New MySqlCommand("select * from tbl_barang where kodebrg='" & vkodebrg.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If Not dr.HasRows Then
                Call koneksi_ok()
                Dim simpan As String = "insert into tbl_barang values('" & vkodebrg.Text & "','" & vnmbrg.Text & "','" & vjenis.Text & "','" & vsatuan.Text & "','" & vhargabeli.Text & "','" & vhrgajual.Text & "','" & vjmlbrg.Text & "')"
                cmd = New MySqlCommand(simpan, conn)
                cmd.ExecuteNonQuery()
            Else
                Call koneksi_ok()
                Dim edit As String = "update tbl_barang set namabrg ='" & vnmbrg.Text & "',jenis='" & vjenis.Text & "',satuan='" & vsatuan.Text & "', hargabeli='" & vhargabeli.Text & "' ,hargajual='" & vhrgajual.Text & "',jumlah='" & vjmlbrg.Text & "' where kodebrg='" & vkodebrg.Text & "'"
                cmd = New MySqlCommand(edit, conn)
                cmd.ExecuteNonQuery()
            End If
            Call bersih()
            Call tampilan()
            Call otomatis()
        End If
    End Sub

    Private Sub Barang_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call koneksi_ok()
        vkodebrg.Enabled = False
        Call otomatis()
        Call tampilan()

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)
        tabel()
    End Sub

    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()

    End Sub

    Private Sub vkodebrg_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub DataGridView1_CellContentClick_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub DataGridView1_CellMouseClick1(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        On Error Resume Next
        vkodebrg.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
        vnmbrg.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
        vjenis.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
        vsatuan.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value
        vhargabeli.Text = DataGridView1.Rows(e.RowIndex).Cells(4).Value
        vhrgajual.Text = DataGridView1.Rows(e.RowIndex).Cells(5).Value
        vjmlbrg.Text = DataGridView1.Rows(e.RowIndex).Cells(6).Value
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        bersih()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If vkodebrg.Text = "" Then
            vkodebrg.Focus()
            MsgBox("Kode  Harus diisi Dulu !")
            Exit Sub
        Else
            If MessageBox.Show("Hapus Data Ini ?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call koneksi_ok()
                Dim hapus As String = "delete from tbl_barang where kodebrg='" & vkodebrg.Text & "'"
                cmd = New MySqlCommand(hapus, conn)
                cmd.ExecuteNonQuery()
                Call bersih()
                Call tampilan()
                Call otomatis()
            Else
                Call bersih()
            End If
        End If
    End Sub

   
    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs)

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If vkodebrg.Text = "" Or vkodebrg.Text = "" Or vjenis.Text = "" Or vsatuan.Text = "" Then
            MsgBox("Masih ada data yang belum dilengkapi")
            Exit Sub
        Else

            Call koneksi_ok()
            cmd = New MySqlCommand("select * from tbl_barang where kodebrg='" & vkodebrg.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If Not dr.HasRows Then
                Call koneksi_ok()
                Dim simpan As String = "insert into tbl_barang values('" & vkodebrg.Text & "','" & vnmbrg.Text & "','" & vjenis.Text & "','" & vsatuan.Text & "','" & vhargabeli.Text & "','" & vhrgajual.Text & "','" & vjmlbrg.Text & "')"
                cmd = New MySqlCommand(simpan, conn)
                cmd.ExecuteNonQuery()
            Else
                Call koneksi_ok()
                Dim edit As String = "update tbl_barang set namabrg ='" & vnmbrg.Text & "',jenis='" & vjenis.Text & "',satuan='" & vsatuan.Text & "', hargabeli='" & vhargabeli.Text & "' ,hargajual='" & vhrgajual.Text & "',jumlah='" & vjmlbrg.Text & "' where kodebrg='" & vkodebrg.Text & "'"
                cmd = New MySqlCommand(edit, conn)
                cmd.ExecuteNonQuery()
            End If
            Call bersih()
            Call tampilan()
            Call otomatis()
        End If
    End Sub
End Class