﻿Imports MySql.Data.MySqlClient
Public Class supplier
    Sub otomatis()
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_supplier order by Id_supplier desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If Not dr.HasRows Then
            vkodesupplier.Text = "SP" + "0001"
        Else
            vkodesupplier.Text = Val(Microsoft.VisualBasic.Mid(dr.Item("Id_supplier").ToString, 4, 3)) + 1
            If Len(vkodesupplier.Text) = 1 Then
                vkodesupplier.Text = "SP000" & vkodesupplier.Text & ""
            ElseIf Len(vkodesupplier.Text) = 2 Then
                vkodesupplier.Text = "SP00" & vkodesupplier.Text & ""
            ElseIf Len(vkodesupplier.Text) = 3 Then
                vkodesupplier.Text = "SP0" & vkodesupplier.Text & ""
            End If
        End If
    End Sub
    Sub tabel()
        Dim i As Integer
        i = Me.DataGridView1.CurrentRow.Index
        With DataGridView1.Rows.Item(i)
            vkodesupplier.Text = .Cells(0).Value
            vnamasup.Text = .Cells(1).Value
            valamatsup.Text = .Cells(2).Value
            vnotlpsup.Text = .Cells(3).Value

        End With
    End Sub
    Private Sub bersih()
        vkodesupplier.Text = ""
        vnamasup.Text = ""
        valamatsup.Text = ""
        vnotlpsup.Text = ""
        vkodesupplier.Focus()
    End Sub
    Private Sub tampilan()
        Call koneksi_ok()
        adr = New MySqlDataAdapter("select * from tbl_supplier", conn)
        adt = New DataSet
        adr.Fill(adt, "tbl_supplier")
        DataGridView1.DataSource = adt.Tables("tbl_supplier")
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If vkodesupplier.Text = "" Or vkodesupplier.Text = "" Then
            MsgBox("Masih ada data yang belum dilengkapi")
            Exit Sub
        Else

            Call koneksi_ok()
            cmd = New MySqlCommand("select * from tbl_supplier where Id_supplier='" & vkodesupplier.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If Not dr.HasRows Then
                Call koneksi_ok()
                Dim simpan As String = "insert into tbl_supplier values('" & vkodesupplier.Text & "','" & vnamasup.Text & "','" & valamatsup.Text & "','" & vnotlpsup.Text & "')"
                cmd = New MySqlCommand(simpan, conn)
                cmd.ExecuteNonQuery()
            Else
                Call koneksi_ok()
                Dim edit As String = "update tbl_supplier set Nama_supplier ='" & vnamasup.Text & "',Alamat_supplier='" & valamatsup.Text & "',Nohp_supplier='" & vnotlpsup.Text & "' where Id_supplier='" & vkodesupplier.Text & "'"
                cmd = New MySqlCommand(edit, conn)
                cmd.ExecuteNonQuery()
            End If
            Call bersih()
            Call tampilan()
            Call otomatis()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If vkodesupplier.Text = "" Then
            vkodesupplier.Focus()
            MsgBox("Kode  Harus diisi Dulu !")
            Exit Sub
        Else
            If MessageBox.Show("Hapus Data Ini ?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call koneksi_ok()
                Dim hapus As String = "delete from tbl_supplier where Id_supplier='" & vkodesupplier.Text & "'"
                cmd = New MySqlCommand(hapus, conn)
                cmd.ExecuteNonQuery()
                Call bersih()
                Call tampilan()
                Call otomatis()
            Else
                Call bersih()
            End If
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        bersih()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        tabel()
    End Sub

    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        On Error Resume Next
        vkodesupplier.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
        vnamasup.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
        valamatsup.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
        vnotlpsup.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value
    End Sub

    Private Sub supplier_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call koneksi_ok()
        vkodesupplier.Enabled = False
        Call otomatis()
        Call tampilan()

    End Sub
End Class