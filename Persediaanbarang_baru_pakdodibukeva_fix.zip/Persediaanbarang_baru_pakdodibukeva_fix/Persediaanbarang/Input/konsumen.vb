﻿Imports MySql.Data.MySqlClient
Public Class konsumen
    Sub otomatis()
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_customer order by Id_konsumen desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If Not dr.HasRows Then
            vkodekonsumen.Text = "KK" + "0001"
        Else
            vkodekonsumen.Text = Val(Microsoft.VisualBasic.Mid(dr.Item("Id_konsumen").ToString, 4, 3)) + 1
            If Len(vkodekonsumen.Text) = 1 Then
                vkodekonsumen.Text = "KK000" & vkodekonsumen.Text & ""
            ElseIf Len(vkodekonsumen.Text) = 2 Then
                vkodekonsumen.Text = "KK00" & vkodekonsumen.Text & ""
            ElseIf Len(vkodekonsumen.Text) = 3 Then
                vkodekonsumen.Text = "KK0" & vkodekonsumen.Text & ""
            End If
        End If
    End Sub
    Sub tabel()
        Dim i As Integer
        i = Me.DataGridView1.CurrentRow.Index
        With DataGridView1.Rows.Item(i)
            vkodekonsumen.Text = .Cells(0).Value
            vnamakon.Text = .Cells(1).Value
            valamat.Text = .Cells(2).Value
            vnotlp.Text = .Cells(3).Value

        End With
    End Sub
    Private Sub bersih()
        vkodekonsumen.Text = ""
        vnamakon.Text = ""
        valamat.Text = ""
        vnotlp.Text = ""
        vkodekonsumen.Focus()
    End Sub
    Private Sub tampilan()
        Call koneksi_ok()
        adr = New MySqlDataAdapter("select * from tbl_customer", conn)
        adt = New DataSet
        adr.Fill(adt, "tbl_customer")
        DataGridView1.DataSource = adt.Tables("tbl_customer")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If vkodekonsumen.Text = "" Or vkodekonsumen.Text = "" Then
            MsgBox("Masih ada data yang belum dilengkapi")
            Exit Sub
        Else

            Call koneksi_ok()
            cmd = New MySqlCommand("select * from tbl_customer where Id_konsumen='" & vkodekonsumen.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If Not dr.HasRows Then
                Call koneksi_ok()
                Dim simpan As String = "insert into tbl_customer values('" & vkodekonsumen.Text & "','" & vnamakon.Text & "','" & valamat.Text & "','" & vnotlp.Text & "')"
                cmd = New MySqlCommand(simpan, conn)
                cmd.ExecuteNonQuery()
            Else
                Call koneksi_ok()
                Dim edit As String = "update tbl_customer set Nama_konsumen ='" & vnamakon.Text & "',Alamat_konsumen='" & valamat.Text & "',Notlp_konsumen='" & vnotlp.Text & "' where Id_konsumen='" & vkodekonsumen.Text & "'"
                cmd = New MySqlCommand(edit, conn)
                cmd.ExecuteNonQuery()
            End If
            Call bersih()
            Call tampilan()
            Call otomatis()
        End If
    End Sub

    Private Sub konsumen_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call koneksi_ok()
        vkodekonsumen.Enabled = False
        Call otomatis()
        Call tampilan()

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        tabel()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        On Error Resume Next
        vkodekonsumen.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
        vnamakon.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
        valamat.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
        vnotlp.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If vkodekonsumen.Text = "" Then
            vkodekonsumen.Focus()
            MsgBox("Kode  Harus diisi Dulu !")
            Exit Sub
        Else
            If MessageBox.Show("Hapus Data Ini ?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call koneksi_ok()
                Dim hapus As String = "delete from tbl_customer where Id_konsumen='" & vkodekonsumen.Text & "'"
                cmd = New MySqlCommand(hapus, conn)
                cmd.ExecuteNonQuery()
                Call bersih()
                Call tampilan()
                Call otomatis()
            Else
                Call bersih()
            End If
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        bersih()
    End Sub
End Class