﻿Imports MySql.Data.MySqlClient
Imports System.Data.OleDb
Public Class Input_Analisa_EOQ
    Dim db As New Db()
    Sub otomatisEOQ()
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_eoq order by noeoq desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If Not dr.HasRows Then
            vkodeeoq.Text = "KE" + "0001"
        Else
            vkodeeoq.Text = Val(Microsoft.VisualBasic.Mid(dr.Item("noeoq").ToString, 4, 3)) + 1
            If Len(vkodeeoq.Text) = 1 Then
                vkodeeoq.Text = "KE000" & vkodeeoq.Text & ""
            ElseIf Len(vkodeeoq.Text) = 2 Then
                vkodeeoq.Text = "KE00" & vkodeeoq.Text & ""
            ElseIf Len(vkodeeoq.Text) = 3 Then
                vkodeeoq.Text = "KE0" & vkodeeoq.Text & ""
            End If
        End If
    End Sub
    Private Sub tampileoq()
        Call koneksi_ok()
        adr = New MySqlDataAdapter("Select * from tbl_eoq", conn)
        adt = New DataSet
        adr.Fill(adt, "tbl_eoq")
        DataGridView1.DataSource = adt.Tables("tbl_eoq")
    End Sub
    Sub panggilbarang()
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_barang", conn)
        dr = cmd.ExecuteReader
        Do While dr.Read
            If dr.HasRows Then
                vkodebarg.Items.Add(dr.Item(0))
            End If
        Loop
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If vkodeeoq.Text = "" Then
            vkodeeoq.Focus()
            MsgBox("Kode  Harus diisi Dulu !")
            Exit Sub
        Else
            If MessageBox.Show("Hapus Data Ini ?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call koneksi_ok()
                Dim hapus As String = "delete from tbl_eoq where noeoq='" & vkodeeoq.Text & "'"
                cmd = New MySqlCommand(hapus, conn)
                cmd.ExecuteNonQuery()  
                Call bersih()
                Call tampilan()
                Call otomatisEOQ()
            Else
                Call bersih()
            End If
        End If
    End Sub
    Private Sub bersih()
        vtgll.Text = ""
        vkodeeoq.Text = ""
        vkodebarg.Text = ""
        vbpesan.Text = ""
        vbsimpan.Text = ""
        vbthun.Text = ""
        veoq.Text = ""
        vkodeeoq.Focus()
        vkodebarg.Focus()
    End Sub
    Private Sub tampilan()
        Call koneksi_ok()
        adr = New MySqlDataAdapter("select * from tbl_eoq", conn)
        adt = New DataSet
        adr.Fill(adt, "tbl_eoq")
        DataGridView1.DataSource = adt.Tables("tbl_eoq")
    End Sub
    Private Sub Input_Analisa_EOQ_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call koneksi_ok()
        vkodeeoq.Enabled = False
        Call otomatisEOQ()
        Call panggilbarang()
        Call tampilan()
        Call tampileoq()
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        On Error Resume Next
        vkodeeoq.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
        vkodebarg.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
        vbpesan.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value
        vbsimpan.Text = DataGridView1.Rows(e.RowIndex).Cells(4).Value
        vbthun.Text = DataGridView1.Rows(e.RowIndex).Cells(5).Value
        veoq.Text = DataGridView1.Rows(e.RowIndex).Cells(6).Value
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Me.Close()
    End Sub

    Private Sub vkodebarg_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles vkodebarg.SelectedIndexChanged
        Call koneksi_ok()
        cmd = New MySqlCommand("select * from tbl_barang where kodebrg ='" & vkodebarg.Text & "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            vnamabrg.Text = dr.Item("namabrg")
           

        Else
            MsgBox("Data Tidak Ada")
            vkodebarg.Focus()
            Exit Sub
        End If

    End Sub

    Private Sub Label15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label15.Click

    End Sub

    Private Sub PROSES_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PROSES.Click
        veoq.Text = ((2 * (Val(vbthun.Text) * Val(vbpesan.Text))) / Val(vbsimpan.Text)) ^ 0.5
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If vkodeeoq.Text = "" Or vkodeeoq.Text = "" Or vkodebarg.Text = "" Then
            MsgBox("Masih ada data yang belum dilengkapi")
            Exit Sub
        Else

            Call koneksi_ok()
            cmd = New MySqlCommand("select * from tbl_eoq where noeoq='" & vkodeeoq.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If Not dr.HasRows Then
                Call koneksi_ok()
                Dim simpan As String = "insert into tbl_eoq values('" & vkodeeoq.Text & "','" & Format(vtgll.Value, "yyyy-MM-dd") & "','" & vkodebarg.Text & "','" & vbpesan.Text & "','" & vbsimpan.Text & "','" & vbthun.Text & "','" & veoq.Text & "')"
                cmd = New MySqlCommand(simpan, conn)
                cmd.ExecuteNonQuery()
            Else
                Call koneksi_ok()
                Dim edit As String = "update tbl_eoq set noeoq ='" & vkodeeoq.Text & "',tgl_eoq='" & Format(vtgll.Value, "yyyy-MM-dd") & "',kodebrg='" & vkodebarg.Text & "', b_pesan='" & vbpesan.Text & "' ,b_simpan='" & vbsimpan.Text & "',k_tahun='" & vbthun.Text & "', eoq='" & veoq.Text & "' where noeoq='" & vkodeeoq.Text & "'"
                cmd = New MySqlCommand(edit, conn)
                cmd.ExecuteNonQuery()
            End If
            Call bersih()
            Call otomatisEOQ()
            Call tampileoq()
        End If
    End Sub
End Class