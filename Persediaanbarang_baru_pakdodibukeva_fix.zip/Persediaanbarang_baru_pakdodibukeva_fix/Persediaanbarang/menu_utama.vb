﻿Public Class menu_utama

    Private Sub BulananToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BulananToolStripMenuItem.Click
        lapbulanan.Show()
    End Sub

    Private Sub DataPembelianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataPembelianToolStripMenuItem.Click
        Formlapbarang.Show()

    End Sub

    Private Sub BarangToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BarangToolStripMenuItem.Click
        Barang.Show()
    End Sub

    Private Sub customerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles customerToolStripMenuItem.Click
        konsumen.Show()
    End Sub

    Private Sub KELUARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KELUARToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub PembelianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PembelianToolStripMenuItem.Click
        Pembelian.Show()
    End Sub

    Private Sub PenjualanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PenjualanToolStripMenuItem.Click
        penjualan1.Show()
        Formpenjualan.Show()


    End Sub

    Private Sub userToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles userToolStripMenuItem.Click, userToolStripMenuItem.Click
        user.Show()

    End Sub

    Private Sub menu_utama_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub HarianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HarianToolStripMenuItem.Click
        lapharian.Show()
    End Sub

    Private Sub TahunToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TahunToolStripMenuItem.Click
        laptahunan.Show()

    End Sub

    Private Sub PersediaanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PersediaanToolStripMenuItem.Click
        Formstockbrg.Show()

    End Sub

    Private Sub SupplierToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SupplierToolStripMenuItem.Click
        supplier.Show()

    End Sub

    Private Sub AnalisaEOQToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AnalisaEOQToolStripMenuItem.Click
        Input_Analisa_EOQ.Show()

    End Sub

    Private Sub DataEOQToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataEOQ.Click
        FormlapEOQ.Show()

    End Sub

    Private Sub DataCustomerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataCustomerToolStripMenuItem.Click
        Formlapcustomer.Show()

    End Sub

    Private Sub DataSupplierToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataSupplierToolStripMenuItem.Click
        Formlapsupplier.Show()

    End Sub

    Private Sub CetakFakturToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CetakFakturToolStripMenuItem.Click
        cetak_faktur.Show()

    End Sub
End Class