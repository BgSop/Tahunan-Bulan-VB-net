﻿Imports Mysql.Data.MySqlClient
Imports System.Data.OleDb
Module koneksi
    Public conn As MySqlConnection
    Public adr As MySqlDataAdapter
    Public adt As DataSet
    Public cmd As MySqlCommand
    Public dr As MySqlDataReader
    Public str, sql As String
    Public hasil As Integer
    Public database As New MySqlConnection
    Public tampil As New MySql.Data.MySqlClient.MySqlCommand
    Public tampilan As MySql.Data.MySqlClient.MySqlDataReader
    Public cari As OleDbDataReader
    Public dml As New OleDbCommand
    Public koneksi As New MySql.Data.MySqlClient.MySqlConnection
    Public sqll As New MySql.Data.MySqlClient.MySqlCommand
    Public dataadapter As New MySql.Data.MySqlClient.MySqlDataAdapter
    Public dataset As New DataSet

    Public Sub koneksi_ok()
        str = "server=localhost;user id=root;password=;database=db_persediaan"
        conn = New MySqlConnection(str)
        If conn.State = ConnectionState.Closed Then
            conn.Open()

        End If
    End Sub
End Module
